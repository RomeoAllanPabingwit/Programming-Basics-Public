for (var mile = 0; mile < 6; mile+2){ //Starting point is 0 mile; condition should not be greater than 6 mile; increment by 2
    mile = mile+2 
        console.log ("Candy")
}

// Stretch Feature 1

var milesPerHour = 5.4
for (var mile = 0; mile < 6; mile+2){
    mile = mile+2
    if (milesPerHour == 5.5 )
    console.log ("Candy")
}
