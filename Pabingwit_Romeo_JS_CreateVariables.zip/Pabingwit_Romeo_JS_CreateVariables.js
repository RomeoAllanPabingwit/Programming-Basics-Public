// Age and height variables met the requirements

var height = 42; // Minimumm height requirement
var age = 11; //  Minimum height requirement
    if (height >= 42 && age > 10) { 
        console.log("You are tall and old enough to ride");
    }
    else
    {
     console.log("Better luck next time");
    }

    // Age variable did not met the requirement

    var height = 42; 
    var age = 10; 
        if (height >= 42 && age > 10) { 
            console.log("You are tall and old enough to ride");
        }
        else
        {
         console.log("Better luck next time");
        }